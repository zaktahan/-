//Shir Shimshi 323013045
#pragma once
int power(int a=1, int b=1);
double power(double a=1, int b=1);
float power(float a=1, int b=1);
int* createAndInput(int& size);
int** createAndInput (int& rows, int& cols);