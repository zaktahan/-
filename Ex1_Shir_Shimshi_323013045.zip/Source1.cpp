//Shir Shimshi 323013045
#include <iostream>
#include "Header1.h"
using namespace std;
//Q1- calculate the power: a is the base and b is the power(/exponent)
//in all of the cases b is a positive int (b>0), 
//and the default value of a and b is 1 as I initialized at the header
int power(int a, int b)
{
	int x = a;
	for (int i = 1; i < b; i++)
		x = x * a;
	return x;
}

double power(double a, int b)
{
	double x = a;
	for (int i = 1; i < b; i++)
		x = x * a;
	return x;
}

float power(float a, int b)
{
	float x = a;
	for (int i = 1; i < b; i++)
		x = x * a;
	return x;
}

//Q2- create an array whose size is determined by the user 
//and receives the elements of the array from the user.
int* createAndInput(int& size)
{
	cout << "Enter the size of the array: ";
	cin >> size;
	// Allocate memory for the array and input the elements according to the user
	int* array = new int[size];
	cout << "Enter " << size << " elements: ";
	for (int i = 0; i < size; ++i) 
		cin >> array[i];
	// Return the pointer to the new array
	return array;

}

//Q3- create a matrix whose sizes is determined by the user 
//and receives the elements of the matrix from the user.
int** createAndInput(int& rows, int& cols) 
{
	cout << "Enter the number of rows: ";
	cin >> rows;
	cout << "Enter the number of columns: ";
	cin >> cols;
	//Allocate memory for the matrix
	int** matrix = new int*[rows];
	for (int i = 0; i < rows; i++)
	{
		matrix[i] = new int[cols];
	}
		// Input elements into the matrix
	for (int i = 0; i < rows; i++)
	{
		for (int j = 0; j < cols; j++)
		{
			cout << "Enter the [" << i << "," << j << "] element" << endl;
			cin >> matrix[i][j];
		}
	}
	// Return the pointer to the new matrix
	return matrix;
}