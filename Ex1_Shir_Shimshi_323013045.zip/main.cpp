﻿//Shir Shimshi 323013045
#include <iostream>
#include "Header1.h"
using namespace std;

int main()
{
    //Using the functions from Q1
    cout << "Question number 1:" << endl;
    //integer cases:
    int a = 5;
    int b = 3;
    cout << "The power of " << a << "^" << b << " is:" << power(a,b) << endl;
    //check the default case
    cout << "The power of " << a << " is:" << power(a) << endl;
    //a double case
    double c = 3.42;
    b = 4;
    cout << "The power of " << c << "^" << b << " is:" << power(c, b) << endl;
    //check the default case
    cout << "The power of " << c << " is:" << power(c) << endl;
    float d = (float)1.784;
    b = 6;
    cout << "The power of " << d << "^" << b << " is:" << power(d, b) << endl;
    //check the default case
    cout << "The power of " << d << " is:" << power(d) << endl;
    
   
    //Using the function from Q2
    cout << "Question number 2:" << endl;
    int size=0;
    int* array = createAndInput(size);
    // Output the elements of the array
    cout << "The elements of the array are: ";
    for (int i = 0; i < size; ++i) 
    {
        cout << array[i] << " ";
    }
    cout << endl;
    cout << "with size " << size << endl;
    // Release the allocated memory
    delete[] array;
    
    //Using the function from Q3
    cout << "Question number 3:" << endl;
    int rows = 0, cols = 0;
    int** matrix= createAndInput(rows,cols);
    // Output the elements of the matrix
    cout << "The elements of the matrix are: "<<endl;
    int j = 0;
    for (int i = 0; i < rows; i++)
    {
        for (j = 0; j < cols; j++)
        {
            cout << " " << matrix[i][j] << " ";
        }
        cout << endl;
    }
    cout << "with size " << rows << "X" << cols << endl;
    // Release the allocated memory
    for (int i = 0; i < rows; i++) 
    {
        delete[] matrix[i];
    }
    delete[] matrix;
    
    return 0;
    
}