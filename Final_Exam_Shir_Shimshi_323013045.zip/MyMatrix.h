//Shir_Shimshi_323013045
#pragma once
#include <iostream>
using namespace std;
#define WRONG_DIMENSION_FOR_MATRIX "The dimensions entered are invalid"
#define MATRIX_SPOT_OUT_OF_RANGE "The indexes are invalid for this matrix (don't exist)"
#define MATRIX_OPERATION_IS_INVALID "The dimensions of the matrices are invalid for this operation"
class MyMatrix
{
private:
	int _m;//number of rows
	int _n;//number of columns
	double** _matrix;//a pointer to a 2D array
	//set number of rows, the default is 3
	void setM(int m = 3);
	//set number of columns, the default is 3
	void setN(int n = 3);

public:
	//Copy constructor 
	MyMatrix(const MyMatrix& other);
	//Constructor of MyMatrix with default values of 3 for the rows and the columns
	MyMatrix(int m = 3, int n = 3);
	//Destructor
	~MyMatrix();
	//a function that returns the num of rows 
	int getM() const;
	//a function that returns the num of cols 
	int getN() const;
	//a function that returns the _matrix 
	double** getMatrix()const;
	//an operator that reads data for MyMatrix from the user  
	friend istream& operator>>(istream& in, const MyMatrix& matrix);
	//the print operator for MyMatrix
	friend ostream& operator<<(ostream& out, const MyMatrix& matrix);
	//add operator for MyMatrix 
	MyMatrix operator+(const MyMatrix& other)const;
	//sub operator for MyMatrix 
	MyMatrix operator-(const MyMatrix& other)const;
	//mult operator that does matrix multiplication MyMatrix*other
	MyMatrix operator*(const MyMatrix& other)const;
	//mult operator of MyMatrix from the right with double scalar: matrix*scalar
	MyMatrix operator*(double num)const;
	//mult operator from the left with double scalar: scalar*matrix
	friend MyMatrix operator*(double num, const MyMatrix& other);
	//mult operator from the right with int scalar: matrix*scalar  
	MyMatrix operator*(int num)const;
	//Mult operator from the left with int scalar: scalar*matrix
	friend MyMatrix operator*(int num, const MyMatrix& other);
	//opartator that sum up all the nums in the matrix 
	operator double()const;
	//operator that compare 2 MyMatrix objects and return true if they are equal
	bool operator==(const MyMatrix& other)const;
	//operator that set all the values of the new matrix as same as the old matrix
	MyMatrix& operator=(const MyMatrix& other);
	//[] operator that returns an array from a specific row in the matrix
	double*& operator[](int num);
	
};