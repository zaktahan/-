﻿// Ex5_Shir_Shimshi_323013045.cpp 
#include "MyMatrix.h"
#include <iostream>
using namespace std;

int main()
{
	//Constructors example
	cout << "*** Examples of constructors: ***" << endl;
	//Deafult constructor
	MyMatrix mat1;
	cout << "Deafult constructor:" << endl;
	cout << "mat1:" << endl << mat1;
	//Regular constructor 
	cout << "example for the constructor of 4x3 matrices: mat2, mat3" << endl;
	MyMatrix mat2(4, 3);
	MyMatrix mat3(4, 3);
	cout << "mat2:" << endl << mat2;
	cout << "mat3:" << endl << mat3;
	//try to set invalid size to MyMatrix 
	cout << "trying to set invalid size to MyMatrix, for example: -1x2:" << endl;
	try
	{
		MyMatrix mat4(-1, 2);
	}
	catch (const char* error)
	{
		cout << "The error is: " << error << endl << endl;
	}
	
	//example of cin>> operator 
	cout << "Set values for mat2 to show the cin>> operator:" << endl;
	cin >> mat2;
	cout << "Print mat2 to show the cout<< operator:" << endl;
	cout << "mat2: " << endl << mat2;
	cout << "Set values for mat3 to show the cin>> operator:" << endl;
	cin >> mat3;
	cout << "Print mat3 to show the cout<< operator:" << endl;
	cout << "mat3: " << endl << mat3;
	//example of copy constructor
	cout << "example of copy constructor: copy mat2 to mat4: " << endl;
	MyMatrix mat4(mat2);
	cout << "mat4:" << endl << mat4;
	//example of the = oparator 
	cout << "example of the = oparator : " << endl;
	MyMatrix mat5 = mat2;
	cout << "mat5=mat2: " << endl << "mat5=" << endl << mat5<<endl;
	//example of the + operator:
	cout << "example of the + operator:" << endl;
	//Try to add matrices  with different sizes (invalid)
	try
	{
		cout << "Try to add matrices  with different sizes (invalid):" << endl;
		cout << "mat1="<<endl<< mat1 << endl <<"mat3="<<endl<< mat3 << endl;
		cout << "mat1+mat3:" << endl;
		mat1 = mat1 + mat3;
	}
	catch (const char* error)
	{
		cout << "The error is: " << error << endl << endl;
	}
	//add matrices with the same sizes:
	cout << "add matrices with the same sizes (using the + operator): mat6 = mat2 + mat3:" << endl;
	MyMatrix mat6 = mat2 + mat3;
	cout << "mat6 =  " << endl << mat6;

	//add 3 matrices in the same time:
	cout << "another example: mat5 = mat2 + mat3 + mat6:" << endl;
	mat5 = mat2 + mat3 + mat6;
	cout << "mat5 =" << endl << mat5;

	//example of the - operator
	cout << "example of the - operator:" << endl;

	MyMatrix mat7 = mat2 - mat3;
	cout << "mat7 =mat2-mat3: " << endl<<"mat7=" <<endl<< mat7<<endl;

	//show associativity of the operators:
	cout << "show an example of associativity of the operators:" << endl;
	mat5 = (mat2 + mat6) - mat3;
	cout << "mat5 = (mat2 + mat6) - mat3:" << endl << "mat5 =" << endl << mat5;
	mat5 = mat2 + (mat6 - mat3);
	cout << "mat5 = mat2 + (mat6 - mat3):" << endl << "mat5 =" << endl << mat5;
	//example of the == oparator:
	cout << "example of the == oparator:" << endl;
	cout << "mat6= " << endl << mat6 << "mat2= " << endl << mat2;
	cout << "mat6==mat2?" << endl;
	if (mat6 == mat2)
		cout << "The matrices are equal" << endl;
	else
		cout << "The matrices are not equal" << endl;
	cout << "mat6==mat6?" << endl;
	if (mat6 == mat6)
		cout << "The matrices are equal" << endl;
	else
		cout << "The matrices are not equal" << endl;
	//examples of mult by scalar (int and double):
	cout << "examples of mult by scalar (int and double) from both sizes:" << endl;
	MyMatrix mat8;
	cout << "set mat8 (3x3):" << endl;
	cin >> mat8;
	cout << "mat9= mat8 * 3:" << endl;
	MyMatrix mat9 = mat8 * 3;
	cout << "mat9= " << endl << mat9 << endl;
	cout << "mat1= -2 * mat8:" << endl;
	mat1 = -2 * mat8;
	cout << "mat1= " << endl << mat1 << endl;
	cout << "mat1= mat1 * 1.6:" << endl;
	mat1 = mat1 * 1.6;
	cout << "mat1= " << endl << mat1 << endl;
	cout << "mat1=2.7 * mat1" << endl;
	mat1 = 2.7 * mat1;
	cout << "mat1= " << endl << mat1 << endl;

	//example of matrix by matrix mult
	cout << "example of matrix by matrix mult (valid sizes):" << endl;
	cout << "mat1= " << endl << mat1 << "mat7= " << endl << mat7;
	cout << "mat10= mat7 * mat1:" << endl;
	MyMatrix mat10 = mat7 * mat1;
	cout << "mat10= " << endl << mat10<<endl;
	//example of matrix by matrix mult (invalid sizes)
	try {
		cout << "example of matrix by matrix mult (invalid sizes): mat1 * mat2 ( (3x3)*(4x3) ):" << endl;
		MyMatrix mat11= mat1 * mat2;
	}
	catch (const char* error)
	{
		cout << "The error is: " << error << endl;
	}
	
	//examples of double(): sum all of the nums in the matrix
	cout << "examples of double(): sum all of the nums in the matrix:" << endl;
	cout << "mat1= " << mat1 << endl;
	cout << "The sum of all the nums in mat1 is: " << double(mat1) << endl;
	cout << "mat5= " << mat5 << endl;
	cout << "The sum of all the nums in mat5 is: " << double(mat5) << endl;
	//examples of the [] operator (valid indexes):
	cout << "examples of the [] operator:" << endl;
	cout << "The number in mat1[1][2] is: " << mat1[1][2] << endl;
	cout << "The number in mat1[2][0] is: " << mat1[2][0] << endl;
	//example of invalid indexes in the matrix:
	try
	{
		cout << "example of invalid indexes in the matrix (enter the indexes [4][2]): " << endl;
		cout << "The number in mat1[4][2] is: " << mat1[4][2] << endl;
	}
	catch (const char* error)
	{
		cout << "The error is: " << error << endl << endl;
	}	

}

