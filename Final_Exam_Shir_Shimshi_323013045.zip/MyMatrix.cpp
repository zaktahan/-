//Shir_Shimshi_323013045
#include "MyMatrix.h"

//Copy constructor 
MyMatrix::MyMatrix(const MyMatrix& other)
{
	//set the num of rows and cols (_m is the num of rows and _n the cols)
	this->setM(other.getM());
	this->setN(other.getN());
	//create a new 2D array- for the new matrix
	this->_matrix = new double* [this->getM()];
	for (int row = 0; row < this->getM(); row++)
	{
		this->_matrix[row] = new double[this->getN()];
	}
	//copy each element from the old matrix into the new matrix
	for (int row = 0; row < this->getM(); row++)
	{
		for (int col = 0; col < getN(); col++)
		{
			this->_matrix[row][col] = other.getMatrix()[row][col];
		}
	}
}

//constructor of MyMatrix with initialized values of 0
MyMatrix::MyMatrix(int m, int n)
{
	//set the num of rows and cols
	this->setM(m);
	this->setN(n);
	//create a new 2D array
	this->_matrix = new double* [this->getM()];
	//create M 1D matrixes 
	for (int row = 0; row < this->getM(); row++)
	{
		this->_matrix[row] = new double[this->getN()];
	}
	//initialize all the values in the matrix to 0
	for (int row = 0; row < this->getM(); row++)
	{
		for (int col = 0; col < getN(); col++)
		{
			this->_matrix[row][col] = 0;
		}
	}
}

//destructor
MyMatrix::~MyMatrix()
{
	//checks if the matrix is not NULL in order to avoid an error of delete NULL
	if (this->getMatrix() != NULL)
	{
		//delete each row
		for (int row = 0; row < this->getM(); row++)
		{
			delete[] this->getMatrix()[row];
		}
		//delete the pointer to the 2D array
		delete[] this->getMatrix();
	}
	cout << "destructor was called" << endl;
}

//set the number of rows
void MyMatrix::setM(int m)
{
	//checks if the input is valid and throw an error if not 
	if (m <= 0)
		throw WRONG_DIMENSION_FOR_MATRIX;
	this->_m = m;
}

//set the number of cols
void MyMatrix::setN(int n)
{
	//checks if the input is valid and throw an error if not 
	if (n <= 0)
		throw WRONG_DIMENSION_FOR_MATRIX;
	this->_n = n;
}

//get the number of rows
int MyMatrix::getM() const
{
	return this->_m;
}

//get the number of cols
int MyMatrix::getN() const
{
	return this->_n;
}

//get the whole matrix
double** MyMatrix::getMatrix() const
{
	return this->_matrix;
}

//an operator that reads data for MyMatrix from the user  
istream& operator>>(istream& in, const MyMatrix& matrix)
{
	//get inputs from the user for each place
	for (int row = 0; row < matrix.getM(); row++)
	{
		for (int col = 0; col < matrix.getN(); col++)
		{
			cout << "Enter value for [" << row << "]" << "," << "[" << col << "]: ";
			//set the new element at this place
			in >> matrix.getMatrix()[row][col];
		}
	}
	return in;
}

//the print operator for MyMatrix
ostream& operator<<(ostream& out, const MyMatrix& matrix)
{
	//print each element of the matrix 
	for (int row = 0; row < matrix.getM(); row++)
	{
		for (int col = 0; col < matrix.getN(); col++)
		{
			if (col == matrix.getN() - 1)
				out << matrix.getMatrix()[row][col];//last element in the row
			else
				out << matrix.getMatrix()[row][col] << ", ";
		}
		out << endl;
	}
	return out;
}

//add operator for MyMatrix 
MyMatrix MyMatrix::operator+(const MyMatrix& other)const
{
	//checks if the operation is valid. if the matrices are not the same sizes- throw error 
	if (this->getM() != other.getM() || this->getN() != other.getN())
		throw MATRIX_OPERATION_IS_INVALID;
	//create a new 2D array in the same size of the matrices in the operation
	MyMatrix resultMatrix(this->getM(), this->getN());
	//for each element in the new matrix perform MyMatrix[i][j] + other[i][j] =resultMatrix[i][j]
	for (int row = 0; row < this->getM(); row++)
	{
		for (int col = 0; col < this->getN(); col++)
		{
			resultMatrix.getMatrix()[row][col] = this->getMatrix()[row][col] + other.getMatrix()[row][col];
		}
	}
	//return the new matrix
	return resultMatrix;
}

//sub operator for MyMatrix 
MyMatrix MyMatrix::operator-(const MyMatrix& other)const
{
	//checks if the operation is valid. if the matrices are not the same sizes- throw error 
	if (this->getM() != other.getM() || this->getN() != other.getN())
		throw MATRIX_OPERATION_IS_INVALID;
	//create a new 2D array in the same size of the matrices in the operation
	MyMatrix resultMatrix(this->getM(), this->getN());
	//for each element in the new matrix perform MyMatrix[i][j] - other[i][j] =resultMatrix[i][j]
	for (int row = 0; row < this->getM(); row++)
	{
		for (int col = 0; col < this->getN(); col++)
		{
			resultMatrix.getMatrix()[row][col] = this->getMatrix()[row][col] - other.getMatrix()[row][col];
		}
	}
	//return the new matrix
	return resultMatrix;
}

//mult operator that does matrix multiplication MyMatrix*other
MyMatrix MyMatrix::operator*(const MyMatrix& other) const
{
	//checks if the operation is valid. if the matrices sizes dont fit- throw error 
	if (this->getN() != other.getM())
		throw MATRIX_OPERATION_IS_INVALID;
	//create a new 2D array in the size of the new matrix
	MyMatrix resultMatrix(this->getM(), other.getN());
	//for each place in the new matrix perform matrix mult by definition 
	for (int row = 0; row < resultMatrix.getM(); row++)
	{
		for (int col = 0; col < resultMatrix.getN(); col++)
		{
			for (int i = 0; i < this->getN(); i++)
			{
				resultMatrix.getMatrix()[row][col] += this->getMatrix()[row][i] * other.getMatrix()[i][col];
			}
		}
	}
	//return the new matrix
	return resultMatrix;
}

//mult operator of MyMatrix from the right with double scalar: matrix*scalar
MyMatrix MyMatrix::operator*(double num) const
{
	//create a new 2D array in the same size of the matrix in the operation
	MyMatrix resultMatrix(this->getM(), this->getN());
	//for each element in the matirx perform MyMatrix[i][j] * num =resultMatrix[i][j]
	for (int row = 0; row < this->getM(); row++)
	{
		for (int col = 0; col < this->getN(); col++)
		{
			resultMatrix.getMatrix()[row][col] = this->getMatrix()[row][col] * num;
		}
	}
	//return the new matrix
	return resultMatrix;
}
//friend- mult operator from the left with double scalar: scalar*matrix
MyMatrix operator*(double num, const MyMatrix& other)
{
	//perform num* MyMatrix[i][j]=resultMatrix[i][j] that is defined in the MyMatrix operator*(double num) const
	return other * num;
}

//mult operator from the right with int scalar: matrix*scalar  
MyMatrix MyMatrix::operator*(int num) const
{
	//create a new 2D array in the same size of the matrix in the operation
	MyMatrix resMatrix(this->getM(), this->getN());
	//for each element in the matirx perform MyMatrix[i][j] * num =resultMatrix[i][j]
	for (int row = 0; row < this->getM(); row++)
	{
		for (int col = 0; col < this->getN(); col++)
		{
			resMatrix.getMatrix()[row][col] = this->getMatrix()[row][col] * num;
		}
	}
	//return the new matrix
	return resMatrix;
}

//friend- mult operator from the left with int scalar: scalar*matrix
MyMatrix operator*(int num, const MyMatrix& other)
{
	//perform num * MyMatrix[i][j]=resultMatrix[i][j] that is defined in the MyMatrix operator*(int num) const
	return other * num;
}

//opartator that sum up all the nums in the matrix 
MyMatrix::operator double()const
{
	double sum = 0;
	//sum up all the elements in the array
	for (int row = 0; row < this->getM(); row++)
	{
		for (int col = 0; col < this->getN(); col++)
		{
			sum += this->getMatrix()[row][col];
		}
	}
	//return the sum of all the elements in the matrix
	return sum;
}

//operator that compare 2 MyMatrix objects and return true if they are equal
bool MyMatrix::operator==(const MyMatrix& other) const
{
	//checks if the matrices are in the same size. if not, return false
	if (this->getM() != other.getM() || this->getN() != other.getN())
		return false;
	//checks if all the elements in the matrices are the same
	for (int row = 0; row < this->getM(); row++)
	{
		for (int col = 0; col < this->getN(); col++)
		{
			//if the elements are diffrent return false
			if (this->getMatrix()[row][col] != other.getMatrix()[row][col])
				return false;
		}
	}
	//the matrices are equal. return true
	return true;
}

//operator that set all the values of the new matrix as same as the old matrix
MyMatrix& MyMatrix::operator=(const MyMatrix& other)
{
	//checks if there is already an old matrix. if there is, delete it
	if (this->getMatrix() != NULL)
	{
		//delete each row
		for (int row = 0; row < this->getM(); row++)
		{
			delete[] this->getMatrix()[row];
		}
		//delete the pointer to the matrix
		delete[] this->getMatrix();
	}
	//set the num of rows and cols
	this->setM(other.getM());
	this->setN(other.getN());
	//create a new 2D array
	this->_matrix = new double* [this->getM()];
	for (int row = 0; row < this->getM(); row++)
	{
		this->_matrix[row] = new double[this->getN()];
	}
	//copy each element from the other matrix into MyMatrix
	for (int row = 0; row < this->getM(); row++)
	{
		for (int col = 0; col < getN(); col++)
		{
			this->getMatrix()[row][col] = other.getMatrix()[row][col];
		}
	}
	//return the copied matrix 
	return *this;
}

//operator that returns an array from a specific row in the matrix
double*& MyMatrix::operator[](int num)
{
	//checks if the input is valid and throw an error if not 
	if (num < 0 || num >= this->getM())
		throw MATRIX_SPOT_OUT_OF_RANGE;
	//return the element
	return this->getMatrix()[num];
}





