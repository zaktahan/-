//Shir Shimshi 323013045
#pragma once
#include <iostream>
#include <string.h>
using namespace std;
class MyDate
{
private:
	int _day=1;
	int _month=1;
	int _year=1;
	char* _comment;
public:
	//a Default Constructor:
	MyDate();
	//a Constructor that gets the day month and year, and an optional comment
	MyDate(int day, int month, int year, const char* = "noComment");
	//Copy Constructor
	MyDate(const MyDate& copyDate);
	//destractor
	~MyDate();
	//a function that sets the day
	void setDay(int day);
	//a function that sets the month
	void setMonth(int month);
	//a function that sets the year
	void setYear(int year);
	//a function that sets the comment	
	void setComment(const char* comment);
	//a function that returns the day 
	int getDay() const
	{
		return _day;
	}
	//a function that returns the month 
	int getMonth() const
	{
		return _month;
	}
	//a function that returns the year 
	int getYear() const
	{
		return _year;
	}
	//a function that returns the comment 
	char* getComment() const
	{
		return _comment;
	}
	//a function that set the day ,month and year
	void setMyDate(int year, int month, int day);
	//a function that sets the date to be the submission date
	void init();
	//a function that increases the date by 1
	MyDate& inc();
	//a function that checks if our date is before a given date
	bool isBefore(const MyDate& other) const;
	//a function that set comment
	void changeComment(const char* newComment);
	//a function that prints MyDate 
	void print()const;
};


