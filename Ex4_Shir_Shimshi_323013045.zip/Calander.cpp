//Shir Shimshi 323013045
#include "Calander.h"
	
//default constructor
Calander::Calander()
{
	_takenDates = 0;
	//initializes all the elements in the calander to NULL
	for (int i = 0; i < DATE_ARR_SIZE; i++)
	{
		this->_dateArr[i] = NULL;
	}
}

Calander::Calander(const Calander& copyCalander)
{
	//initializes all the elements in the calander to NULL
	for (int i = 0; i < DATE_ARR_SIZE; i++)
	{
		this->_dateArr[i] = NULL;
	}
	//copy each element
	for (int i = 0; i < DATE_ARR_SIZE; i++)
	{
		if (copyCalander._dateArr[i] != NULL)
			this->setDate((i+1), *copyCalander._dateArr[i]);
	}
	//copy the _takenDates 
	this->_takenDates = copyCalander._takenDates;
}

Calander::~Calander()
{
	//Delete the entire calander
	this->deleteAll();
}

void Calander::setDate(int num, const MyDate& date)
{	//Check if the user provided a valid num to the calander 
	if (0 < num && num < (DATE_ARR_SIZE+1))
	{
		//Check if the place is already full, or empty:
		if (this->_dateArr[num-1] != NULL)
		{
			this->deleteDate(num);
		}
		this->_takenDates++;
		this->_dateArr[num-1] = new MyDate(date);
	}
	//if this is an invalid num:
	else
	{
		cout << "Your input is invalid!" << endl;
	}
}


bool Calander::isFree(int num) const
{
	//Check if the user provided a valid num: 
	if (0 < num && num < (DATE_ARR_SIZE+1))
	{
		//Check if this place in the array is full or empty
		if (this->_dateArr[num-1] == NULL)
			return true;
		return false;
	}
	//an invalid num: 
	cout << "Your input is invalid!" << endl;
	return false;
}

int Calander::firstFree() const
{
	//Find the first free place in the array: 
	for (int i = 0; i < DATE_ARR_SIZE; i++)
	{
		if (this->isFree(i+1))
			return (i+1);
	}
	//if there is no free place at all:
	return -1;
}

bool Calander::insert(MyDate& date)
{
	//If the calander isn't full, find the first free place and set the new date  
	if (this->firstFree() != -1)
		this->setDate(this->firstFree(), date);
	//If the calander is full: 
	else
	{
		cout << "The calander is full!" << endl;
		return false;
	}
}

int Calander::oldest() const
{
	//initialize for the case where the calander is empty
	int temp = 0;
	//check which date is the oldest using the isBefore function
	for (int i = 0; i < 30; i++)
	{
		for (int j = 0; j < 30; j++)
		{
			if (this->_dateArr[i] && this->_dateArr[j]) //checks if there is a valid date
				if (i != j && this->_dateArr[i]->isBefore(*(this->_dateArr[j]))) //check for multiplicity
					temp = i;
		}
	}
	return (temp+1);
}

int Calander::datesNum() const
{
	//Return _takenDates
	return this->_takenDates;
}

void Calander::deleteAll()
{
	//Delete all the MyDate elements from the array
	for (int i = 1; i <= DATE_ARR_SIZE; i++)
	{
		this->deleteDate(i);
	}
}

void Calander::deleteDate(int num)
{
	//Checks if there is a date at this place/number in the calander
	if (this->_dateArr[num-1] != NULL)
	{
		delete this->_dateArr[num-1];
		this->_dateArr[num-1] = NULL;
		this->_takenDates--;
	}
}

void Calander::printSpecificDate(int num)const
{
	//checks if there is a date in the recquired num, or it is empty
	if (!this->isFree(num))
		this->_dateArr[num-1]->print();
	else
		cout << "you wanted to print an empty date" << endl;
}

void Calander::print() const
{
	//Check if the calander is not empty
	bool flag = false;
	for (int i = 0; i < DATE_ARR_SIZE; i++)
	{
		if (this->_dateArr[i] != NULL)
		{
			flag = true;
			break;
		}
	}
	//if the calander is empty:
	if(flag==false)
	{
	cout << "Empty Calander" << endl;
	}
	//print the calander
	else
	{
		cout << "*****Start_of_the_Calander*****" << endl;
		//print only the dates that are not NULL:
		for (int i = 0; i < DATE_ARR_SIZE; i++)
		{
			if (this->_dateArr[i] != NULL)
			{
				cout << "The date number " << (i+1) << " in the calander is: ";
				this->_dateArr[i]->print();
			}
		}
		cout << "*****End_of_the_Calander*****" << endl;
	}
	cout << endl;
}
