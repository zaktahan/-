#include "MyDate.h"
//Shir Shimshi 323013045

MyDate::MyDate()
{
	//Create an object of MyDate with the parmaters of 1/1/2020 and "noComment"
	this->setMyDate(1, 1, 2020);
	this->setComment("noComment");
}

MyDate::MyDate(int day, int month, int year, const char* comment)
{
	//Create an object of MyDate with the given parmaters
	this->setDay(day);
	this->setMonth(month);
	this->setYear(year);
	this->setComment(comment);
}

MyDate::MyDate(const MyDate& copyDate)
{
	//Create an object that is a copy of another MyDate object 
	this->setMyDate(copyDate.getYear(), copyDate.getMonth(), copyDate.getDay());
	this->setComment(copyDate.getComment());
}

MyDate::~MyDate()
{
	//Delete the dyanmaic allocation of the memory 
	delete[] this->getComment();

}

void MyDate::setDay(int day)
{
	//According to the instructions, the valid days depend on the months: 
	//according to the table:
	//(we dont have to check the month, because this check is done in setMonth function)
	switch (this->getMonth())
	{
		//2
	case 2:
	{
		if (1 <= day && day <= 28)
			_day = day;
		else
			_day = 1;
		break;
	}
	//4,6,9,11
	case 4: case 6: case 9: case 11:
	{
		if (1 <= day && day <= 30)
			_day = day;
		else
			_day = 1;
		break;
	}
	//1,3,5,7,8,10,12
	case 1: case 3: case 5: case 7: case 8: case 10: case 12:
	{
		if (1 <= day && day <= 31)
			_day = day;
		else
			_day = 1;
		break;
	}
	default:
	{
		break;
	}
	}
}

void MyDate::setMonth(int month)
{
	//Check if the month is valid
	if (1 <= month && month <= 12)
		_month = month;
	//if the month is invalid:
	else
		_month = 1;
}

void MyDate::setYear(int year)
{
	//Check if the year is valid
	if (1 <= year)
		_year = year;
	//if the year is invalid:
	else
		_year = 1;
}

void MyDate::setComment(const char* comment)
{	
	//check that the user entered a comment
	if (comment != NULL)
	{
		if (this->getComment() != NULL)
		{
			//Delete the old comment
			delete[] _comment;
		}
		//a Dynamic allocation for the new comment 
		char* temp = new char[strlen(comment) + 1];
		strcpy_s(temp, strlen(comment) + 1, comment);
		_comment = temp;
	
	}
}

void MyDate::init()
{
	//initiallize to the submittimg date
	this->setMyDate(2024, 7, 4);
	this->setComment("The date of submitting the exercise");
}

void MyDate::setMyDate(int year, int month, int day)
{
	this->setYear(year);
	this->setMonth(month);
	this->setDay(day);
}

MyDate& MyDate::inc()
{
	//Checks at what month we are
	switch (this->getMonth())
	{
	//2
	case 2:
	{
		//If MyDate is 28, the day reset to 1 and the month increases in 1
		if (this->getDay() == 28)
		{
			this->setDay(1);
			this->setMonth(3);
		}
		else
		{
			this->setDay(this->getDay() + 1);
		}
		break;
	}
	//4,6,9,11
	case 4: case 6: case 9: case 11:
	{
		//If MyDate is 30, the day reset to 1 and the month increases in 1
		if (this->getDay() == 30)
		{
			this->setDay(1);
			this->setMonth(this->getMonth() + 1);
		}
		else
		{
			this->setDay(this->getDay() + 1);
		}
		break;
	}
	//1,3,5,7,8,10
	case 1: case 3: case 5: case 7: case 8: case 10:
	{
		//If MyDate is 31, the day reset to 1 and the month increases in 1 
		if (this->getDay() == 31)
		{
			this->setDay(1);
			this->setMonth(this->getMonth() + 1);
		}
		else
		{
			this->setDay(this->getDay() + 1);
		}
		break;
	}
	//12
	case 12:
	{
		//If MyDate is 31, the day and month reset to 1 and the year increases in 1
		if ((this->getDay()) == 31)
		{
			this->setDay(1);
			this->setMonth(1);
			this->setYear((this->getYear() + 1));
		}
		else
		{
			this->setDay((this->getDay() + 1));
		}
		break;
	}
	default:
	{
		break;
	}
	}
	//return the updated object
	return *this;
}

bool MyDate::isBefore(const MyDate& anotherDate) const
{
	//check if the year of anotherDate is greater
	if (this->getYear() < anotherDate.getYear())
	{
		return true;
	}
	//if the year is equal, check if the month of anotherDate is greater
	if (this->getYear() == anotherDate.getYear())
	{
		if (this->getMonth() < anotherDate.getMonth())
		{
			return true;
		}
		//if the month is equal, check if the day of anotherDate is greater
		if (this->getMonth() == anotherDate.getMonth())
		{
			if (this->getDay() < anotherDate.getDay())
			{ 
				return true;
			}
		}
	}
	//if the dates are equal or the anotherDay is before, return false:
	return false;
}

void MyDate::changeComment(const char* comment)
{
	//Set the new comment:
	this->setComment(comment);
}

void MyDate::print() const
{
	//print MyDate in th required format: dd/mm/yyyy
	if (10 <= this->getDay() && this->getDay() <= 31)
		cout << this->getDay() << "/";
	else		cout << "0" << this->getDay() << "/";

	if (10 <= this->getMonth() && this->getMonth() <= 12)
		cout << this->getMonth() << "/";
	else
		cout << "0" << this->getMonth() << "/";

	if (this->getYear() < 10)
		cout << "000" << this->getYear();
	else if (this->getYear() < 100)
		cout << "00" << this->getYear();
	else if (this->getYear() < 1000)
		cout << "0" << this->getYear();
	else
		cout << this->getYear();
	//print the comment:
	if (this->getComment() != NULL)
		cout << " The comment in MyDate is: " << this->getComment() << endl;
}
