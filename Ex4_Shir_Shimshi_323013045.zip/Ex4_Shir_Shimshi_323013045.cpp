﻿// Ex4_Shir_Shimshi_323013045.cpp : This file contains the 'main' function. Program execution begins and ends there.
//
#include "MyDate.h"
#include <iostream>
#include "Calander.h"
using namespace std;

int main()
{
	cout << "*****Shir Shimshi 323013045*****" << endl;
	cout << "*****Examples_part_a*****" << endl;
	//default constractor 
	cout << "*Example of default constactor of Mydate- d1:*" << endl;
	MyDate d1;
	d1.print();
	//copy constractor 
	cout << "*Example of copy constractor: d1 to d2*" << endl;
	MyDate d2(d1);
	d2.print();
	//changeComment and getComment:
	cout << "*Example of changeComment and getComment*" << endl;
	d2.changeComment("Shir_Shimshi");
	cout << d2.getComment() << endl;
	//regular constructor
	cout << "*Examples of constructors that gets all the needed parameters: for both d3, d4*" << endl;
	MyDate d3(5, 4, 2001, "MyBirthDay");
	d3.print();
	MyDate d4(3, 8, 1948, "a regular day");
	d4.print();
	//init function: 
	cout << "*Example of init function- d2*" << endl;
	d2.init();
	d2.print();
	//isBefore function 
	cout << "*Example of is before function on d4 and d1*" << endl;
	if (d4.isBefore(d1))
		cout << "d4 is before d1" << endl;
	else
		cout << "d1 is before d4" << endl;
	cout << endl;
	cout << "*Example of set and get functions on d3:(31,12,1999,The_last_day_of_the_year) * " << endl;
	d3.setYear(1999); 
	d3.setMonth(12);
	d3.setDay(31);
	d3.setComment("The_last_day_of_the_year");
	cout<<d3.getDay()<<endl;
	cout<<d3.getMonth()<<endl;
	cout<<d3.getYear()<<endl;
	cout<<d3.getComment()<<endl;
	//inc function 
	cout << "*Example of inc function on d3 (and changing the comment)*" << endl;
	d3.inc();
	d3.setComment("The_first_day_of_the_year");
	d3.print();
	cout << "*Example of inc function on d2*" << endl;
	d2.inc();
	d2.print();

	cout << "*****Examples_part_b*****" << endl;
	//Example of adding the dates to the calander and print it
	cout << "*Example of adding d1, d2, d3, d4 to the calander and print it*" << endl;
	cout << endl;
	Calander c1;
	MyDate d5(13, 4, 1743);
	MyDate d6(1, 7, 2024, "Summer");
	MyDate d7(28, 4, 1755);
	MyDate d8(15, 3, 1767, "Andrew Jacksone");
	c1.insert(d1);
	c1.insert(d2);
	c1.insert(d3);
	c1.insert(d4);
	c1.print();
	cout << endl;
	//Example of insert function
	cout << "*Example of insert function of d5*" << endl;
	c1.insert(d5);
	cout << endl;
	//Example of setDate function
	cout << "*Example of setDate function of d6 to the 8th position*" << endl;
	c1.setDate(8,d6);
	cout << endl;
	//Example of the function isFree 
	//print again all the calander
	cout << "The updated calander is now: ";
	c1.print();
	cout << "*** Examples of the function isFree ***" << endl;
	if (c1.isFree(1))
		cout << "The position 1 is free" << endl;
	else
		cout << "The position 1 is occupied" << endl;
	if (c1.isFree(10))
		cout << "The position 10 is free" << endl;
	else
		cout << "The position 10 is occupied" << endl;	
	cout << "The number of occupied dates is: " << c1.datesNum() << endl;
	cout << "The first place that is free in the calander is: " << c1.firstFree() << endl;
	cout << "destractor of Mydate in position 1" << endl;
	c1.deleteDate(1);
	cout << "The number of occupied dates now is: " << c1.datesNum() << endl;
	cout << "The first place that is free in the calander now is: " << c1.firstFree() << endl;
	cout << endl;
	//Example of the setDate function
	cout << "*Example of the setDate function: (28, 4, 1755)*" << endl;
	c1.setDate(30, d7);
	cout << "The new element in spot 30: ";
	c1.printSpecificDate(30);
	cout << endl;
	//print again all the calander
	cout << "The updated calander is now: ";
	c1.print();
	cout << "use all the destractors" << endl;
	return 0;

	
}



