//Shir Shimshi 323013045
#pragma once
#include "MyDate.h"
#include <iostream>
//in order to create an array of 30 pointers
#define DATE_ARR_SIZE 30
using namespace std;

class Calander
{
private:
	MyDate* _dateArr[DATE_ARR_SIZE];
	int _takenDates;
public:
	//default constructor
	Calander();
	//copy constructor
	Calander(const Calander& copyCalander);
	//destractor
	~Calander();
	//Function that sets a date in the calander at a specific place/num 
	void setDate(int num, const MyDate& date);
	//Function the checks if a specific place in the calander is free
	bool isFree(int numOfDate) const;
	//Function that returns the first free place/num in the calander
	int firstFree() const;
	//Function that insert a date at the first free place in the calander
	bool insert(MyDate& date);
	//Function that returns the place of the oldest date in the calander
	int oldest() const;
	//Function that returns the num of taken dates
	int datesNum() const;
	//Function that deletes the entire calander
	void deleteAll();
	//Function the deletes a specific place (date) in the calander
	void deleteDate(int dateNum);
	//Function that prints a specific MyDate in the calander
	void printSpecificDate(int day)const;
	//Function that prints the entire calander
	void print() const;

};