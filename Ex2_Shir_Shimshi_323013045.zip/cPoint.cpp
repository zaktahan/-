//Shir Shimshi 323013045
#include "cPoint.h"
using namespace std;

void cPoint::setPoint(int x, int y)
{
	//set the x,y values of the point
	_x = x;
	_y = y;
}

int cPoint::getX()
{
	return _x;
}

int cPoint::getY()
{
	return _y;
}

void const cPoint::printPoint()
{
	cout << "(" << _x << "," << _y << ")" << endl;
}