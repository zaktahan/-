//Shir Shimshi 323013045
#include "cRect.h"
using namespace std;

void cRect::set(int num, cPoint dot)
{
	if (num < 4 & num>=0) {
		_points[num] = dot;
	}
	else {
		cout << "the number need to be between 0-3" << endl;
	}
	//we set the new point in the required position (number, between 0-3)
}
void cRect::printRect()
{
	//print all the 4 points of the rectangle, from 0 to 3, clockwise 
	for (int i = 0; i < 4; i++)
		_points[i].printPoint();
}
int cRect::calcArea()
{
	//calculeta the area of the rectangle
	int width = 0, height = 0;
	width = _points[1].getX() - _points[0].getX();
	height = _points[1].getY() - _points[2].getY();
	return width * height;
}
cPoint cRect::get(int num)
{	
	//return the point in the required position
	if (num<4 & num>=0){
		return _points[num];
	}
	else {
		cout << "the number need to be between 0-3" << endl;
	}
	}
