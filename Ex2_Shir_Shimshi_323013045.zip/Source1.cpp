﻿//Shir Shimshi 323013045
//Ex2
#include<iostream>
#include"cPoint.h"
#include"cRect.h"
using namespace std;

int main()
{
	cout << " Ex2 Shir Shimshi 323013045" << endl;
	cRect rect;
	cPoint tempDot, newDot, dot1, dot2;;
	int x, y, num;
	//initialize a new rectangle using the set function:
	tempDot.setPoint(-1,3);
	rect.set(0, tempDot);
	tempDot.setPoint(5, 3);
	rect.set(1, tempDot);
	tempDot.setPoint(5,-2);
	rect.set(2, tempDot);
	tempDot.setPoint(-1,-2);
	rect.set(3, tempDot);
	//print this rectangle using the printRect function:
	cout << "The initial points of the rectangle are:" << endl;
	rect.printRect();
	//use the get function in oder to get the (x,y) of a wanted point:
	num = 2;
	newDot = rect.get(num);
	//print the wanted point using the printPoint function:
	cout << "The value of point number "<<num<<" for example is: (using the get function)" << endl;
	newDot.printPoint();
	//print the area of the rectangle using the calcArea function
	cout << "The area of the recgtanle is:" << rect.calcArea() << endl;
	//use the set function in order to update the size of the old rectangle:
	cout << "We set the values of 2 points of the rectangle. the updated rectangle is:" << endl;
	dot1.setPoint(-2, 3);
	dot2.setPoint(-2, -2);
	rect.set(0, dot1);
	rect.set(3, dot2);
	rect.printRect();
	//use the get function in oder to get the (x,y) of a wanted point:
	num = 0;
	newDot = rect.get(num);
	cout << "The value of point number " << num << " for example is: (using the get function)" << endl;
	newDot.printPoint();
	//print the area of the rectangle using the calcArea function
	cout << "The area of the new rectangle is: " << rect.calcArea() << endl;

}
