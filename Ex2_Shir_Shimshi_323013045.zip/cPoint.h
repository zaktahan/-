//Shir Shimshi 323013045
#pragma once
#include<iostream>
using namespace std;

class cPoint
{
private:
	int _x = 0;
	int _y = 0;

public:
	void setPoint(int x, int y);
	//functions that return x, y
	int getX();
	int getY();
	//a function that prints (x,y)
	void const printPoint();

};

