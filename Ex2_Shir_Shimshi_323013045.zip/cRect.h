//Shir Shimshi 323013045
#pragma once
#include<iostream>
#include "cPoint.h"
using namespace std;

class cRect
{
private:
	//the rectangle includes 4 points, from 0 to 3
	cPoint _points[4];

public:
	//this function gets a number between 0-3 and return this point
	cPoint get(int num);
	void set(int num, cPoint dot);
	void printRect();
	int calcArea();
};

