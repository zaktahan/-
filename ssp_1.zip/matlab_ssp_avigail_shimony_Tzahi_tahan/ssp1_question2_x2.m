N1=1024
%v2 = 1; % Variance of the white noiseS
sigma2=sqrt(0.51)
% Generate Gaussian white noise sequence w2[n] with zero mean and specified variance
w2 = sigma2*randn(1, N1);

% Initialize the AR process
x2 = zeros(1, N1);
a = 0.7; % AR coefficient

% Generate AR process
for n = 2:N1
    x2(n) = a * x2(n-1) + w2(n);
end

% Compute the autocorrelation
r = xcorr(x2,"biased");

% Create a vector for the x-axis representing the lag values
lags = -N1+1:N1-1;

% Plot the autocorrelation function
figure;
plot(lags, abs(r));
title('The biased correlation value x2[n]');
xlabel('n');
ylabel('Autocorrelation');
% Define the frequency axis 
omega = linspace(0, pi, 2049);

% Calculate the correlogram
Pxx = zeros(1, length(omega));
for k = 1:length(omega)
    Pxx(k) = sum(r .* exp(-1j * omega(k) * (-N1+1:N1-1)));
end
a=imag(Pxx)
b=max(a)
% Plot the correlogram
figure;
plot(omega, abs(Pxx));
title('Correlogram of x2[n]');
xlabel('Frequency');
ylabel('Power Spectral Density');
xlim([0, pi]);

%% 

% Define the frequency range
w = linspace(0, pi, 2049);

%spectrum 
sxx2 = 0.51 ./(1.49 - 1.4*cos(w));

figure;
hold on;

plot(w, sxx2, 'g', 'DisplayName', 'spectrum of X_2[n]');

%Periodogram 
%parameters
N = 1024;
N2 = 4096;
freq = linspace(0, 2*pi, N2);
sigma2 = sqrt(0.51);
w2 = sigma2*randn(1, N);
x2 = zeros(1, N);
a = 0.7;
%create x2
for n = 2:N
    x2(n) = a* x2(n-1) + w2(n);
end
x2 = [x2, zeros(1, N2 - N)];
X2 = fft(x2);
Pxx2 = (1/N) * abs(X2).^2;

title('peiodogram of x2[n]');
xlabel('Frequency');
ylabel('Power Spectral Density');
xlim([0, pi]);
%% 

x2 = zeros(1, N);
a = 0.7; 

%create x2
for n = 2:N
    x2(n) = a *x2(n-1) + w2(n);
end

% Autocorrelation
r=xcorr(x2,"biased");

% Create a vector for the x-axis
lags = -N+1:N-1;

% Define the frequency axis 
omega = linspace(0, pi, 2049);

%  correlogram
Pxx = zeros(1, length(omega));
for k = 1:length(omega)
    Pxx(k) = sum(r .* exp(-1j * omega(k) * (-N+1:N-1)));
end
a=imag(Pxx);
b=max(a)

% Plot the correlogram
plot(omega, (Pxx), 'b', 'DisplayName', 'Correlogram of x2[n]');
title('Spectrum ,Periodogram and Correlogram of X_2[n]');
xlabel('Frequency ');
ylabel('Power/Frequency');

% Add legend to distinguish the plots
legend;

grid on;
xlim([0 pi]);

hold off;


