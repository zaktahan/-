% Calculate the spectrum 
w = linspace(0, pi, 2049);
sxx2 = 0.51 ./(1.49 - 1.4*cos(w));
sxx2 = abs(sxx2);

% Define parameters
N = 1024; 
num_Monte_Carlo = 100; % Number of Monte Carlo experiments
M = 4096; 
f_samples = M/2 + 1; 
sigma2 = sqrt(0.51); 

% Initializations
Pxx_A_all = zeros(f_samples, num_Monte_Carlo);
Pxx_B_all = zeros(f_samples, num_Monte_Carlo);
Pxx_welch_all = zeros(f_samples, num_Monte_Carlo);
Pxx_welch_all_B = zeros(f_samples, num_Monte_Carlo);
Pxx_mean_all = zeros(f_samples, num_Monte_Carlo);
Pxx_mean_all_l4 = zeros(f_samples, num_Monte_Carlo);

% Bartlett Method Parameters
L_A = 64; 
K_A = 16; 

L_B = 16; 
K_B = 64; 

% Welch's Method Parameters
L_welch = 64; 
D_welch = 48; 
K_welch = 61; 

L_welch_B = 16; 
D_welch_B = 12; 
K_welch_B = 253; 

% Generate spectrum
Sxx2 = sxx2(1:f_samples);

% Bartlett and Welch Methods
for r = 1:num_Monte_Carlo
    w2 = sigma2 * randn(N, 1); % Generate white noise
    
    % Create X2[n] 
    X2 = zeros(N, 1);
    for n = 2:N
        X2(n) = 0.7 * X2(n-1) + w2(n);
    end
    
    % Bartlett's Method
    Pxx_A = bartlett_method(X2, L_A, K_A, M);
    Pxx_A_all(:, r) = Pxx_A;
    
    % Create x2[n] for Welch's Method
    x2 = zeros(N, 1);
    for n = 2:N
        x2(n) = 0.7 * x2(n-1) + w2(n);
    end
    
    % Welch's Method
    Pxx_welch = welch_method(x2, L_welch, D_welch, K_welch, M);
    Pxx_welch_all(:, r) = Pxx_welch;
end

for r = 1:num_Monte_Carlo
    w2 = sigma2 * randn(N, 1); % Generate white noise
    
    % Create X2[n] for Bartlett's Method
    X2 = zeros(N, 1);
    for n = 2:N
        X2(n) = 0.7 * X2(n-1) + w2(n);
    end
    
    % Bartlett's Method
    Pxx_B = bartlett_method(X2, L_B, K_B, M);
    Pxx_B_all(:, r) = Pxx_B;
    
    % Create x2[n] for Welch's Method
    x2 = zeros(N, 1);
    for n = 2:N
        x2(n) = 0.7 * x2(n-1) + w2(n);
    end
    
    % Welch's Method
    Pxx_welch_B = welch_method(x2, L_welch_B, D_welch_B, K_welch_B, M);
    Pxx_welch_all_B(:, r) = Pxx_welch_B;
end

% Another Method (l = 2)
N2 = 4098;
l = 2;
Pxx_mean_all = zeros(f_samples, num_Monte_Carlo);

for r = 1:num_Monte_Carlo
    w2 = sigma2 * randn(1, N);  % Generate white noise
    
    % Generate x2[n]
    x2 = zeros(1, N);
    a = 0.7; 
    for n = 2:N
        x2(n) = a * x2(n-1) + w2(n);
    end
    
    % Calculate autocorrelation
    r_auto = xcorr(x2, "biased");
    r_auto = circshift(r_auto, -1023 + l);
    r_auto = r_auto(1:2*l+1);
    
    % Padding with zeros
    numElementsToPad = N2 - length(r_auto);
    r_auto = [r_auto, zeros(1, numElementsToPad)];
    
    s = fft(r_auto);
    Pxx_mean_all(:, r) = s(1:f_samples);
end

meanPxx_mean = mean(Pxx_mean_all, 2);

% Another Method Calculation (l = 4)
l = 4;
Pxx_mean_all_l4 = zeros(f_samples, num_Monte_Carlo);

for r = 1:num_Monte_Carlo
    w2 = sigma2 * randn(1, N);  % Generate white noise
    
    % Generate x2[n]
    x2 = zeros(1, N);
    a = 0.7; 
    for n = 2:N
        x2(n) = a * x2(n-1) + w2(n);
    end
    
    % Calculate autocorrelation
    r_auto = xcorr(x2, "biased");
    r_auto = circshift(r_auto, -1023 + l);
    r_auto = r_auto(1:2*l+1);
    
    % Padding with zeros
    numElementsToPad = N2 - length(r_auto);
    r_auto = [r_auto, zeros(1, numElementsToPad)];
    
    s = fft(r_auto);
    Pxx_mean_all_l4(:, r) = s(1:f_samples);
end

meanPxx_mean_l4 = mean(Pxx_mean_all_l4, 2);

% Calculate the mean
meanPxx_A = mean(Pxx_A_all, 2);
meanPxx_welch = mean(Pxx_welch_all, 2);
meanPxx_B = mean(Pxx_B_all, 2);
meanPxx_welch_B = mean(Pxx_welch_all_B, 2);

% Calculate Bias, Variance, and MSE
bias_A = meanPxx_A - Sxx2';
variance_A = mean((Pxx_A_all - meanPxx_A).^2, 2);
mse_A = variance_A + (bias_A).^2;

bias_welch = meanPxx_welch - Sxx2';
variance_welch = mean((Pxx_welch_all - meanPxx_welch).^2, 2);
mse_welch = variance_welch + bias_welch.^2;

bias_B = meanPxx_B - Sxx2';
variance_B = mean((Pxx_B_all - meanPxx_B).^2, 2);
mse_B = variance_B + (bias_B).^2;

bias_welch_B = meanPxx_welch_B - Sxx2';
variance_welch_B = mean((Pxx_welch_all_B - meanPxx_welch_B).^2, 2);
mse_welch_B = variance_B + (bias_B).^2;

bias_mean = meanPxx_mean - Sxx2';
variance_mean = mean((Pxx_mean_all - meanPxx_mean).^2, 2);
mse_mean =  variance_mean + (bias_mean).^2;

bias_mean_l4 = meanPxx_mean_l4 - Sxx2';
variance_mean_l4 = mean((Pxx_mean_all_l4 - meanPxx_mean_l4).^2, 2);
mse_mean_l4 =  variance_mean_l4 + (bias_mean_l4).^2;

% Plots
figure;
plot(w(1:f_samples), bias_A, 'DisplayName', 'Bias Bartlett L=64');
hold on;
plot(w(1:f_samples), bias_B, 'DisplayName', 'Bias Bartlett L=16');
plot(w(1:f_samples), bias_welch, 'DisplayName', 'Bias Welch L=64, D=48');
plot(w(1:f_samples), bias_welch_B, 'DisplayName', 'Bias Welch L=16, D=12');
plot(w(1:f_samples), bias_mean, 'DisplayName', 'Bias New Method l=2');
plot(w(1:f_samples), bias_mean_l4, 'DisplayName', 'Bias New Method l=4');
title('Bias');
xlabel('Frequency');
ylabel('Bias');
xlim([0 pi]);
legend('show');
hold off;

figure;
plot(w(1:f_samples), variance_A, 'DisplayName', 'Variance Bartlett L=64');
hold on;
plot(w(1:f_samples), variance_B, 'DisplayName', 'Variance Bartlett L=16');
plot(w(1:f_samples), variance_welch, 'DisplayName', 'Variance Welch L=64, D=48');
plot(w(1:f_samples), variance_welch_B, 'DisplayName', 'Variance Welch L=16, D=12');
plot(w(1:f_samples), variance_mean, 'DisplayName', 'Variance New Method l=2');
plot(w(1:f_samples), variance_mean_l4, 'DisplayName', 'Variance New Method l=4');
title('Variance');
xlabel('Frequency');
ylabel('Variance');
xlim([0 pi]);
legend('show');
hold off;

figure;
plot(w(1:f_samples), mse_A, 'DisplayName', 'MSE Bartlett L=64');
hold on;
plot(w(1:f_samples), mse_B, 'DisplayName', 'MSE Bartlett L=16');
plot(w(1:f_samples), mse_welch, 'DisplayName', 'MSE Welch L=64, D=48');
plot(w(1:f_samples), mse_welch_B, 'DisplayName', 'MSE Welch L=16, D=12');
plot(w(1:f_samples), mse_mean, 'DisplayName', 'MSE BT l=2');
plot(w(1:f_samples), mse_mean_l4, 'DisplayName', 'MSE BT l=4');
title('Mean Square Error');
xlabel('Frequency');
ylabel('MSE');
xlim([0 pi]);
legend('show');
hold off;

function [Pxx] = bartlett_method(x, L, K, M)
    Pxx = zeros(M/2 + 1, 1);
    for k = 1:K
        segment = x((k-1)*L + 1:k*L);
        segment_fft = fft(segment, M);
        periodogram = (1 / L) * abs(segment_fft(1:M/2 + 1)).^2;
        Pxx = Pxx + periodogram;
    end
    Pxx = Pxx / K;
end

function [Pxx] = welch_method(x, L, D, K, M)
    N = length(x);
    Pxx = zeros(M/2 + 1, 1);
    
    for k = 1:K
        start_idx = (k-1) * (L - D) + 1;
        end_idx = start_idx + L - 1;
        if end_idx > N
            break;
        end
        
        segment = x(start_idx:end_idx);
        windowed_segment = segment; 
        segment_fft = fft(windowed_segment, M);
        periodogram = (1 / L) * abs(segment_fft(1:M/2 + 1)).^2;
        Pxx = Pxx + periodogram;
    end
    Pxx = Pxx / k;
end
