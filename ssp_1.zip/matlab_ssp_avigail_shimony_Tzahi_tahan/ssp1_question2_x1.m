N = 1024;
%create white noise
sigma1=sqrt(1/26)
w1 = sigma1*randn(1, N);

% Define the coefficients 
coefficients = [1 -3 -4];

% Filter the white noise to create x1[n]
x1 = filter(coefficients, 1, w1);

% Compute the autocorrelation
r = xcorr(x1,"biased");

% Create a vector for the x-axis 
lags = -N+1:N-1;

% Plot the autocorrelation
figure;
plot(lags, r);
title('the biased correlation value x1[n]');
xlabel('n');
ylabel('Autocorrelation');

% Define the frequency axis
omega = linspace(0, pi, 2049);

% Calculate the correlogram
Pxx = zeros(1, length(omega));
for k = 1:length(omega)
    Pxx(k) = sum(r .* exp(-1j * omega(k) * (-N+1:N-1)));
end
a=imag(Pxx)
b=max(a)
% Plot the correlogram
figure;
plot(omega, abs(Pxx));
title('Correlogram of x1[n]');
xlabel('Frequency');
ylabel('Power Spectral Density');
xlim([0, pi]);

%% 

% Define the frequency range
w = linspace(0, pi, 2049);

% Compute the power spectral density
sxx1 = (26-8*cos(2*w)+18*cos(w))/26;

% Create a figure and hold on to add multiple plots
figure;
hold on;

% Plot the power spectral density
plot(w, sxx1, 'k', 'DisplayName', 'spectrum of X_1[n]'); 
xlim([0, pi]);
%% 


% Second plot - Periodogram Spectrum of x1
N = 1024;
sigma1 = sqrt(1/26);
w1 = sigma1*randn(1, N);
coefficients = [1 -3 -4];
x1 = filter(coefficients, 1, w1);
N2 = 4096;
x1 = [x1, zeros(1, N2 - N)];
X1 = fft(x1);
Pxx = (1/N) * abs(X1).^2;
freq = linspace(0, 2*pi, N2);

plot(freq, Pxx, 'b', 'DisplayName', 'Periodogram Spectrum of X_1[n]');
xlim([0, pi]);
%% 


% Third plot - Correlogram of x1[n]
sigma1 = sqrt(1/26);
w1 = sigma1*randn(1, N);
x1 = filter(coefficients, 1, w1);
r = xcorr(x1, "biased");
lags = -N+1:N-1;
omega = linspace(0, pi, 2049);
Pxx = zeros(1, length(omega));
for k = 1:length(omega)
    Pxx(k) = sum(r .* exp(-1j * omega(k) * lags));
end

plot(omega, abs(Pxx), 'b', 'DisplayName', 'Correlogram of X_1[n]');

% Add title and axis labels
title('spectrum ,Periodogram and  Correlogram of X_1[n]');
xlabel('Frequency (radians/sample)');
ylabel('Power/Frequency');
xlim([0 pi]);

% Add legend to distinguish the plots
legend;

% Add grid
grid on;

% Release the hold
hold off;
