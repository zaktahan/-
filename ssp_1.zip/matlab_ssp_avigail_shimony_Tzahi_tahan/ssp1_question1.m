
% Define the frequency range
w = linspace(0, pi, 2049);

% Compute the power spectral density
sxx1 = (26-8*cos(2*w)+18*cos(w))/26;
sxx2=abs(sxx1);

% Plot the Spectrum of x_1[n]
figure;
plot(w,(sxx1)); 
title('Spectrum of x_1[n]');
xlabel('Frequency (radians/sample)');
ylabel('Power/Frequency');
xlim([0 pi]);
grid on;

sxx2 = 0.51 ./(1.49 - 1.4*cos(w));

sxx2=abs(sxx2);
% Plot the Spectrum of x_2[n]
figure;
plot(w,(sxx2));
title(' Spectrum of x_2[n]');
xlabel('Frequency (radians/sample)');
ylabel('Power/Frequency');
xlim([0 pi]);
grid on;

