﻿// Ex3_Shir_Shimshi_323013045.cpp : This file contains the 'main' function. Program execution begins and ends there.
#include "Complex.h"
#include <math.h>
#include<iostream>
using namespace std;

int main() {
    cout << "Shir Shimshi 323013045" << endl;
    cout << "run #1:" << endl;
    Complex a1;
    Complex a2(-11);
    Complex a3(2, -4);
    Complex a4(a3);

    cout << "a1 (default): ";
    a1.print();

    cout << "a2 (real number): ";
    a2.print();

    cout << "a3 (complex number): ";
    a3.print();

    cout << "a4 (use the copy constructor and copy a3):";
    a4.print();

    // Addition
    Complex a5 = a2.add(a3);
    cout << "a2 + a3: ";
    a5.print();

    // Subtraction
    Complex a6 = a2.sub(a3);
    cout << "a2 - a3: ";
    a6.print();

    cout << "run #2:" << endl;
    Complex b1(2);
    Complex b2(-3,-1);
    Complex b3(12, -2);
    Complex b4(b2);

    cout << "b1 (real): ";
    b1.print();

    cout << "b2: ";
    b2.print();

    cout << "b3: ";
    b3.print();

    cout << "b4 (use the copy constructor and copy b2):";
    b4.print();

    // Addition
    Complex b5 = b2.add(b3);
    cout << "b2 + b3: ";
    b5.print();

    // Subtraction
    Complex b6 = b4.sub(b1);
    cout << "b4 - b1: ";
    b6.print();

    cout << "run #3:" << endl;
    Complex c1(-7);
    Complex c2(-30,9);
    Complex c3(0, -5);
    Complex c4(c2);

    cout << "c1 (real): ";
    c1.print();

    cout << "c2: ";
    c2.print();

    cout << "c3: ";
    c3.print();

    cout << "c4 (use the copy constructor and copy c2):";
    c4.print();
    //addition:
    Complex c5 = c2.add(c3);
    cout << "c2 + c3: ";
    c5.print();

    Complex c6 = c4.sub(c1);
    cout << "c4 - c1: ";
    c6.print();

    return 0;
}
