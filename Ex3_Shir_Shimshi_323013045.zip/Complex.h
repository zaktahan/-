#pragma once
#define _USE_MATH_DEFINES
#include<iostream>
using namespace std;
//Shir Shimshi
#include <iostream>
#include <math.h>

class Complex {
private:
    int _real;
    int _imaginary;

    void setReal(int r);
    void setImaginary(int i);

public:
    //default constructor
    Complex();
    // Constructor for real number only
    Complex(int r);
    // Constructor for complex number
    Complex(int r, int i);
    // Copy constructor
    Complex(const Complex& other);
    //set both the real and imaginary parts of the number
    void set(int r, int i); 
    // get the real part of the number
    int getReal() const;
    // get the imaginary part of the number
    int getImaginary() const;
    // Addition of 2 complex numbers
    Complex add(const Complex& other) const;
    // Subtraction of 2 complex numbers 
    Complex sub(const Complex& other) const;
    // Print function
    void print() const;
    // Get the norm (magnitude) of the complex number
    double getNorm() const;
    // Get the phase of the complex number
    double getPhase() const;
};

