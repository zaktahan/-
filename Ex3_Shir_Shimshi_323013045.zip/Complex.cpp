//Shir Shimshi
#include "Complex.h"
#include <math.h>
#include<iostream>
using namespace std;

//set the real part of the number
void Complex::setReal(int r) {
    _real = r;
}

//set the imaginary part of the number
void Complex::setImaginary(int i) {
    _imaginary = i;
}


// Default constructor
Complex::Complex() {
    _real = 0;
    _imaginary = 0;
}

// Constructor for real number only
Complex::Complex(int r) {
    _real = r;
    _imaginary = 0;
}

// Constructor for complex number
Complex::Complex(int r, int i) {
    _real = r;
    _imaginary = i;
}

// Copy constructor
Complex::Complex(const Complex& other) {
    _real = other.getReal();
    _imaginary = other.getImaginary();
}

//set both the real and imaginary parts of the number
void Complex::set(int r, int i) {
    _real = r;
    _imaginary = i;
}

// get the real part of the number
int Complex::getReal() const {
    return _real;
}

// get the imaginary part of the number
int Complex::getImaginary() const {
    return _imaginary;
}

// Addition of 2 complex numbers
Complex Complex::add(const Complex& other) const {
    Complex temp;
    temp.set(_real + other.getReal(), _imaginary + other.getImaginary());
    return temp;
}

// Subtraction of 2 complex numbers 
Complex Complex::sub(const Complex& other) const {
    Complex temp;
    temp.set(this->getReal() - other.getReal(), this->getImaginary() - other.getImaginary());
    return temp;
}

// Print function
void Complex::print() const {
    //if the number is 0:
    if (this->getReal() == 0 && this->getImaginary() == 0) {
        cout << "0" << endl;
        return;
    }
    //if the number is pure imaginary:
    if (this->getReal() == 0) {
        cout << this->getImaginary() << "i ("
            << this->getNorm() << ", " << this->getPhase() << ")" << endl;
        return;
    }
    //if the number is only real:
    if (this->getImaginary() == 0) {
        cout << this->getReal() << " (" << this->getNorm() << ", "
            << this->getPhase() << ")" << endl;
        return;
    }
    //if the number has real part and negative imaginary part:
    if (this->getImaginary() < 0) {
        cout << this->getReal() << this->getImaginary() << "i ("
            << this->getNorm() << ", " << this->getPhase() << ")" << endl;
        return;
    }
    //if the number has real part and positive imaginary part:
    cout << this->getReal() << " + " << this->getImaginary() << "i ("
        << this->getNorm() << ", " << this->getPhase() << ")" << endl;
}

// Get the norm (magnitude) of the complex number
double Complex::getNorm() const {
    return sqrt(pow(this->getReal(),2) + pow(this->getImaginary() ,2));
}

// Get the phase of the complex number
double Complex::getPhase() const {
    double phase = atan2(double(this->getImaginary()), double(this->getReal()));
    //to present the phase in positive:
    if (phase<0){ 
    phase= phase + 2 * M_PI;
    }
    return phase;
}
